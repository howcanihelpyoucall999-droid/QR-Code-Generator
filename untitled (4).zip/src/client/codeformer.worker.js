// CodeFormer worker stub for async messaging compatibility.

self.onmessage = async (e) => {
  const { id, type } = e.data || {};
  if (type === "load") {
    self.postMessage({ type: "progress", payload: { stage: "ready" } });
    self.postMessage({ type: "loaded", id });
  } else if (type === "run") {
    self.postMessage({ type: "result", id, rgba: e.data.rgba });
  }
};
