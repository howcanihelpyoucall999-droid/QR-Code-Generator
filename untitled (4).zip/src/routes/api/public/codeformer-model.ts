import { createFileRoute } from "@tanstack/react-router";

const CANDIDATE_URLS = [
  "https://huggingface.co/Xenova/swin2SR-lightweight-x2-64/resolve/main/onnx/model.onnx",
  "https://huggingface.co/Xenova/4x_APISR_GRL_GAN_generator-onnx/resolve/main/onnx/model.onnx",
];

export const Route = createFileRoute("/api/public/codeformer-model")({
  server: {
    handlers: {
      GET: async () => {
        for (const url of CANDIDATE_URLS) {
          try {
            const res = await fetch(url, { method: "HEAD" });
            if (res.ok) {
              return Response.redirect(url, 302);
            }
          } catch {
            // Try next candidate
          }
        }
        return Response.redirect(CANDIDATE_URLS[0], 302);
      },
    },
  },
});
