# Fix CodeFormer enhance: no lag, no vanishing photo

## What's wrong today

Two separate bugs, both in the enhance path.

**1. The photo disappears after enhancing.**
`enhance.js` hands the enhanced image to `window.__tryOn.applyResult()`. That function is the *try-on* result handler: it re-runs the background-removal model (MODNet) on the enhanced image, rebuilds a cutout, and renders that. So enhancing silently strips the background — and when the mask comes back weak or empty, the result looks like the picture was deleted. Second cause: when the skin-tone face locator in `codeformer.js` finds no face, the code stretches the 512x512 model output over the *entire* photo, replacing the real image with a soft/garbled 512px render.

**2. It lags on phones and desktop.**
CodeFormer runs with `executionProviders: ["wasm"]` only, with `numThreads = 1` on any non-cross-origin-isolated page (i.e. always, here). Inference plus the per-pixel tensor conversion loops all run on the main thread, so the whole UI freezes for the duration. The forced background-removal pass on top of it doubles the work, and `scale: 2` upscaling with a full-size PNG `toDataURL()` adds a large memory spike on mobile.

## The fix

**Stop enhance from destroying the image**
- Add a dedicated `window.__tryOn.applyEnhancedSource(dataUrl)` in `src/client/app.js` that replaces the source canvas and re-renders using the *existing* mask/cutout state — no new background-removal pass, no aspect refit. `enhance.js` calls this instead of `applyResult`.
- In `codeformer.js`, when no face box is found, keep the original photo as the base and blend the restored 512 result only over a centred face-sized region — never scale it over the whole frame. Same guard when the detected box is implausibly large.
- Keep revert working against the same new path.

**Remove the lag**
- Move model loading and inference into a Web Worker (`src/client/codeformer.worker.js`). The main thread only sends the 512x512 face pixels and receives the restored pixels, so the page stays responsive and scrolling/animation no longer stalls.
- Try `webgpu` execution provider first, fall back to `wasm`; raise `wasm.numThreads` to `min(4, hardwareConcurrency)` when threads are usable, and use `wasm.proxy` where the worker path needs it.
- Do the pre/post pixel conversion inside the worker on transferable buffers (no copies across the boundary).
- Cap work on mobile: clamp the upscale so total output pixels stay under a safe budget (default `1x` on low-memory/mobile devices, `2x` on desktop), and encode the result as JPEG at high quality instead of a full PNG data URL when the image is large.
- Keep the existing IndexedDB model cache and first-run progress card, driven by worker messages.

**Deliverables**
- Apply all of the above to this project so the chat preview runs the fixed build (client bundle rebuilt via `scripts/build-client.mjs`).
- Produce an updated zip of the whole project for download.

## Technical notes

Files touched: `src/client/codeformer.js`, new `src/client/codeformer.worker.js`, `src/client/enhance.js`, `src/client/app.js` (new `applyEnhancedSource`), `scripts/build-client.mjs` (worker entry point + keep `onnxruntime-web/webgpu` external so the importmap in `public/index.html` still resolves it from CDN — the worker gets its own importmap-free direct CDN import). No server, schema, or API changes. Background removal and try-on behaviour stay exactly as they are today.

## Verification

Run the app in the preview, upload a portrait, hit Enhance: the photo must stay visible with its background intact, only facial detail sharpened, and the UI must stay interactive (scroll/tap) while the model runs. Repeat with an image containing no detectable face to confirm the photo is returned unharmed.
