// Manual Dress Editor. "Change Dress" opens a full-screen editor showing the
// exact preview image (cut-out subject, selected ratio and background) where
// the user picks (or uploads) a garment and places it with drag / resize /
// rotate. "Apply" composites it and hands the result to the existing preview
// pipeline via window.__tryOn.applyResult().

import { openModal, closeActiveModal, showToast } from "./modals-manager.js";

const GARMENTS = [
  { id: "g1", label: "Formal", img: "/garments/1.png" },
  { id: "g2", label: "White Tee", img: "/garments/2.png" },
  { id: "g3", label: "Shirt", img: "/garments/3.png" },
  { id: "g4", label: "T-Shirt", img: "/garments/4.png" },
  { id: "g5", label: "Traditional", img: "/garments/5.png" },
  { id: "g6", label: "Blazer", img: "/garments/6.png" },
  { id: "g7", label: "Suit", img: "/garments/7.png" },
  { id: "g8", label: "Kurta", img: "/garments/8.png" },
  { id: "g9", label: "Saree", img: "/garments/9.png" },
  { id: "g10", label: "Hoodie", img: "/garments/10.png" },
];

const $ = (id) => document.getElementById(id);

let preTryOnSnapshot = null;
let preTryOnDims = null;
let baseDims = null;
let lastResultDataUrl = null;
let busy = false;

// Editor state
let baseImg = null; // HTMLImageElement of the person photo
let garmentImg = null; // HTMLImageElement of the chosen garment
let layer = { x: 0, y: 0, w: 0, h: 0, rot: 0 }; // in stage (display) pixels
let builtUI = false;

function setStatus(msg, kind = "") {
  const el = $("tryOnStatus");
  if (!el) return;
  el.textContent = msg || "";
  el.className = "tryOnStatus " + kind;
}

function setEditorStatus(msg) {
  const el = $("dressEditorStatus");
  if (el) el.textContent = msg || "";
}

function updateGenerateBtn() {
  const btn = $("tryOnGenerate");
  if (!btn) return;
  btn.disabled = busy || !window.__tryOn?.getPersonDataUrl?.();
  btn.textContent = "Change Dress";
}

/* ---------------------------------------------------------------- UI build */

function buildEditorUI() {
  if (builtUI) return;
  builtUI = true;

  const overlay = document.createElement("div");
  overlay.id = "dressEditorModal";
  overlay.className = "appModalOverlay dressEditorOverlay hidden";
  overlay.innerHTML = `
    <div class="appModalBox dressEditorBox">
      <div class="appModalHeader">
        <span class="appModalTitle">Dress Editor</span>
        <button type="button" id="dressEditorClose" class="appModalCloseBtn" aria-label="Close">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
            <path d="M6 6l12 12M18 6L6 18" />
          </svg>
        </button>
      </div>
      <div class="dressEditorBody">
        <div class="dressEditorStageWrap">
          <div id="dressEditorStage" class="dressEditorStage">
            <canvas id="dressEditorBase" class="dressEditorBase"></canvas>
            <div id="dressEditorLayer" class="dressEditorLayer hidden">
              <img id="dressEditorGarment" alt="Garment overlay" draggable="false" />
              <span class="dressHandle dressHandleScale" data-handle="scale"></span>
              <span class="dressHandle dressHandleRotate" data-handle="rotate"></span>
            </div>
          </div>
          <div id="dressEditorStatus" class="dressEditorStatus"></div>
        </div>
        <div class="dressEditorSide">
          <div class="dressEditorSideTitle">Choose a garment</div>
          <div id="dressEditorGrid" class="dressEditorGrid"></div>
          <label id="dressEditorDrop" class="dressEditorDrop">
            <input id="dressEditorFile" type="file" accept="image/*" hidden />
            <span>Drag &amp; drop your own garment image, or click to upload</span>
          </label>
          <div class="dressEditorHint">
            Drag the garment to move it. Use the bottom-right handle to resize and
            the top-right handle to rotate.
          </div>
          <div class="dressEditorActions">
            <button type="button" id="dressEditorApply" class="tryOnBtn primary" disabled>Apply</button>
            <button type="button" id="dressEditorCancel" class="tryOnBtn ghost">Cancel</button>
          </div>
        </div>
      </div>
    </div>`;
  document.body.appendChild(overlay);

  renderGarmentGrid();
  bindEditorEvents();
}

function renderGarmentGrid() {
  const wrap = $("dressEditorGrid");
  if (!wrap) return;
  wrap.innerHTML = "";
  GARMENTS.forEach((g) => {
    const el = document.createElement("button");
    el.type = "button";
    el.className = "dressEditorThumb";
    el.dataset.id = g.id;
    el.innerHTML = `<span class="dressEditorThumbImg"><img src="${g.img}" alt="${g.label}" loading="lazy" onerror="this.closest('.dressEditorThumb').classList.add('missing')" /></span><span class="dressEditorThumbLabel">${g.label}</span>`;
    el.onclick = async () => {
      wrap
        .querySelectorAll(".dressEditorThumb")
        .forEach((n) => n.classList.toggle("active", n === el));
      try {
        await setGarment(g.img);
      } catch {
        setEditorStatus("That garment image is not available yet — upload your own.");
      }
    };
    wrap.appendChild(el);
  });
}

/* ------------------------------------------------------------ editor logic */

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not load image"));
    img.src = src;
  });
}

/**
 * @param {{fromOriginal?: boolean}} opts
 *   fromOriginal — Retry: always restart from the true original person photo
 *   (the pre-try-on snapshot), never from the last try-on result, so garments
 *   can never stack on top of each other.
 */
async function openEditor(opts = {}) {
  if (!window.__tryOn) {
    setStatus("Editor not ready yet — upload a photo first.", "err");
    return;
  }
  const personDataUrl = window.__tryOn.getPersonDataUrl();
  if (!personDataUrl) {
    setStatus("Upload a person photo first.", "err");
    return;
  }
  buildEditorUI();
  if (!preTryOnSnapshot) {
    preTryOnSnapshot = personDataUrl;
    const snap = await loadImage(personDataUrl);
    preTryOnDims = { w: snap.naturalWidth, h: snap.naturalHeight };
  }

  // Retry restores the original photo into the preview pipeline first, so the
  // editor base is the untouched person, not the previous result.
  if (opts.fromOriginal && preTryOnSnapshot) {
    setStatus("Starting again from your original photo…");
    await window.__tryOn.applyResult(preTryOnSnapshot, (m) => setStatus(m), preTryOnDims);
    lastResultDataUrl = null;
  }

  // Base layer = exactly what the Preview panel shows: background removed and
  // rendered at the selected ratio.
  const baseUrl = window.__tryOn.getPreviewDataUrl?.() || personDataUrl;
  baseImg = await loadImage(baseUrl);
  baseDims = { w: baseImg.naturalWidth, h: baseImg.naturalHeight };
  clearGarment();
  setEditorStatus("Pick a garment to start placing it.");
  // The modal must be visible BEFORE any measurement: while it is hidden
  // getBoundingClientRect() returns 0 and the garment would be sized against a
  // zero-width stage (the old clipping / tiny-box bug).
  openModal("dressEditorModal");
  await nextLayoutFrame();
  drawBase();
}

/** Resolves after the browser has laid the (now visible) modal out. */
function nextLayoutFrame() {
  return new Promise((resolve) =>
    requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
  );
}

function drawBase() {
  const canvas = $("dressEditorBase");
  const stage = $("dressEditorStage");
  if (!canvas || !baseImg || !stage) return;
  canvas.width = baseImg.naturalWidth;
  canvas.height = baseImg.naturalHeight;
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(baseImg, 0, 0);
  // Stage matches the rendered canvas box so overlay coords stay in sync.
  const rect = canvas.getBoundingClientRect();
  stage.style.width = rect.width ? `${rect.width}px` : "auto";
  stage.style.height = rect.height ? `${rect.height}px` : "auto";
}

function clearGarment() {
  garmentImg = null;
  const l = $("dressEditorLayer");
  if (l) l.classList.add("hidden");
  const apply = $("dressEditorApply");
  if (apply) apply.disabled = true;
}

async function setGarment(src) {
  garmentImg = await loadImage(src);
  // Re-measure the stage right now — the modal is visible and laid out, so
  // these are the real dimensions the garment can be dragged across.
  drawBase();
  const canvas = $("dressEditorBase");
  let rect = canvas.getBoundingClientRect();
  if (!rect.width || !rect.height) {
    await nextLayoutFrame();
    drawBase();
    rect = canvas.getBoundingClientRect();
  }
  const stageW = rect.width || canvas.width;
  const stageH = rect.height || canvas.height;
  const targetW = stageW * 0.6;
  const ratio = garmentImg.naturalHeight / garmentImg.naturalWidth;
  layer = {
    x: (stageW - targetW) / 2,
    y: stageH * 0.32,
    w: targetW,
    h: targetW * ratio,
    rot: 0,
  };
  const imgEl = $("dressEditorGarment");
  imgEl.src = garmentImg.src;
  $("dressEditorLayer").classList.remove("hidden");
  $("dressEditorApply").disabled = false;
  syncLayer();
  setEditorStatus("Drag to move • corner handle to resize • top handle to rotate");
}

function syncLayer() {
  const l = $("dressEditorLayer");
  if (!l) return;
  l.style.left = `${layer.x}px`;
  l.style.top = `${layer.y}px`;
  l.style.width = `${layer.w}px`;
  l.style.height = `${layer.h}px`;
  l.style.transform = `rotate(${layer.rot}rad)`;
}

/* ------------------------------------------------- drag / resize / rotate */

function bindPointerControls() {
  const stage = $("dressEditorStage");
  const l = $("dressEditorLayer");
  if (!stage || !l) return;

  let mode = null;
  let start = null;

  const stagePoint = (e) => {
    const r = stage.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  const onDown = (e) => {
    if (!garmentImg) return;
    const handle = e.target.dataset?.handle;
    mode = handle || "move";
    const p = stagePoint(e);
    start = {
      p,
      layer: { ...layer },
      cx: layer.x + layer.w / 2,
      cy: layer.y + layer.h / 2,
    };
    start.dist = Math.hypot(p.x - start.cx, p.y - start.cy) || 1;
    start.angle = Math.atan2(p.y - start.cy, p.x - start.cx);
    l.setPointerCapture?.(e.pointerId);
    e.preventDefault();
  };

  const onMove = (e) => {
    if (!mode || !start) return;
    const p = stagePoint(e);
    if (mode === "move") {
      layer.x = start.layer.x + (p.x - start.p.x);
      layer.y = start.layer.y + (p.y - start.p.y);
    } else if (mode === "scale") {
      const dist = Math.hypot(p.x - start.cx, p.y - start.cy);
      const k = Math.max(0.1, dist / start.dist);
      const w = Math.max(24, start.layer.w * k);
      const h = Math.max(24, start.layer.h * k);
      layer.x = start.cx - w / 2;
      layer.y = start.cy - h / 2;
      layer.w = w;
      layer.h = h;
    } else if (mode === "rotate") {
      const angle = Math.atan2(p.y - start.cy, p.x - start.cx);
      layer.rot = start.layer.rot + (angle - start.angle);
    }
    syncLayer();
    e.preventDefault();
  };

  const onUp = () => {
    mode = null;
    start = null;
  };

  l.addEventListener("pointerdown", onDown);
  window.addEventListener("pointermove", onMove, { passive: false });
  window.addEventListener("pointerup", onUp);
  window.addEventListener("pointercancel", onUp);
}

/* ------------------------------------------------------- apply / composite */

function compositeToDataUrl() {
  const canvas = document.createElement("canvas");
  canvas.width = baseImg.naturalWidth;
  canvas.height = baseImg.naturalHeight;
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(baseImg, 0, 0);

  const stageRect = $("dressEditorBase").getBoundingClientRect();
  const k = canvas.width / (stageRect.width || canvas.width);
  const cx = (layer.x + layer.w / 2) * k;
  const cy = (layer.y + layer.h / 2) * k;
  const w = layer.w * k;
  const h = layer.h * k;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(layer.rot);
  ctx.drawImage(garmentImg, -w / 2, -h / 2, w, h);
  ctx.restore();

  return canvas.toDataURL("image/png");
}

async function applyEdit() {
  if (!garmentImg || !baseImg || busy) return;
  busy = true;
  const applyBtn = $("dressEditorApply");
  if (applyBtn) {
    applyBtn.disabled = true;
    applyBtn.textContent = "Applying…";
  }
  try {
    const dataUrl = compositeToDataUrl();
    lastResultDataUrl = dataUrl;
    closeActiveModal();
    setStatus("Applying your new look…");
    await window.__tryOn.applyResult(dataUrl, (m) => setStatus(m), baseDims);
    $("tryOnRevert").classList.remove("hidden");
    const rtBtn = $("tryOnRetry");
    if (rtBtn) rtBtn.classList.remove("hidden");
    setStatus("Outfit applied. Tap Edit again to adjust it.", "ok");
    showToast("Outfit applied", "success");
  } catch (e) {
    setStatus(e?.message || "Could not apply the garment.", "err");
  } finally {
    busy = false;
    if (applyBtn) applyBtn.textContent = "Apply";
    updateGenerateBtn();
  }
}

async function revert() {
  if (!preTryOnSnapshot || busy) return;
  busy = true;
  updateGenerateBtn();
  setStatus("Restoring original…");
  try {
    await window.__tryOn.applyResult(preTryOnSnapshot, (m) => setStatus(m), preTryOnDims);
    $("tryOnRevert").classList.add("hidden");
    const rtBtn = $("tryOnRetry");
    if (rtBtn) rtBtn.classList.add("hidden");
    preTryOnSnapshot = null;
    lastResultDataUrl = null;
    setStatus("Reverted to original.", "ok");
  } catch (e) {
    setStatus(e?.message || "Could not revert.", "err");
  } finally {
    busy = false;
    updateGenerateBtn();
  }
}

/* --------------------------------------------------------------- bindings */

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error("Could not read image"));
    r.readAsDataURL(file);
  });
}

async function useCustomFile(file) {
  if (!file || !file.type.startsWith("image/")) {
    setEditorStatus("Please choose an image file.");
    return;
  }
  const dataUrl = await readFileAsDataUrl(file);
  $("dressEditorGrid")
    .querySelectorAll(".dressEditorThumb")
    .forEach((n) => n.classList.remove("active"));
  await setGarment(dataUrl);
}

function bindEditorEvents() {
  bindPointerControls();

  $("dressEditorClose").onclick = () => closeActiveModal();
  $("dressEditorCancel").onclick = () => closeActiveModal();
  $("dressEditorApply").onclick = applyEdit;

  const input = $("dressEditorFile");
  input.addEventListener("change", (e) => useCustomFile(e.target.files?.[0]));

  const drop = $("dressEditorDrop");
  ["dragenter", "dragover"].forEach((ev) =>
    drop.addEventListener(ev, (e) => {
      e.preventDefault();
      drop.classList.add("over");
    }),
  );
  ["dragleave", "drop"].forEach((ev) =>
    drop.addEventListener(ev, (e) => {
      e.preventDefault();
      drop.classList.remove("over");
    }),
  );
  drop.addEventListener("drop", (e) => useCustomFile(e.dataTransfer?.files?.[0]));

  window.addEventListener("resize", () => {
    if (!$("dressEditorModal")?.classList.contains("hidden")) drawBase();
  });
}

function bind() {
  const gen = $("tryOnGenerate");
  if (gen) gen.onclick = () => openEditor();
  const rev = $("tryOnRevert");
  if (rev) rev.onclick = revert;
  const rtBtn = $("tryOnRetry");
  // Retry always rebuilds from the original photo (no stacked garments).
  if (rtBtn) rtBtn.onclick = () => openEditor({ fromOriginal: true });

  const dresses = $("tryOnDresses");
  if (dresses) dresses.innerHTML = "";
  const custom = $("tryOnCustom");
  if (custom) custom.classList.add("hidden");

  const obs = new MutationObserver(updateGenerateBtn);
  const resultView = document.getElementById("resultView");
  if (resultView) obs.observe(resultView, { attributes: true, attributeFilter: ["class"] });
  updateGenerateBtn();
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind);
else bind();

export { lastResultDataUrl };
